-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: May 30, 2024 at 02:54 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `events_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `EVENT_NAME` varchar(120) NOT NULL,
  `EVENT_DATE` date NOT NULL,
  `EVENT_TIME` time NOT NULL,
  `EVENT_VENUE` varchar(120) NOT NULL,
  `EVENT_ORGANIZER` varchar(60) NOT NULL,
  `EVENT_DETAILS` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`EVENT_NAME`, `EVENT_DATE`, `EVENT_TIME`, `EVENT_VENUE`, `EVENT_ORGANIZER`, `EVENT_DETAILS`) VALUES
('Film Showing', '2024-01-01', '00:00:09', 'Caloocan', 'Teachers', 'Film Showing of classical Films'),
('Inter Strand Sports Event', '2024-06-01', '00:00:09', 'Covered Court', 'ICT Strand', 'Inter Strand Sports Event'),
('Quiz Bee', '2024-06-02', '00:00:09', 'Caloocan', 'Teachers', 'Quiz Bee'),
('Symposium', '2024-02-02', '00:00:09', 'ICC Court', 'ICT Strand', 'Research Symposium of ICC');

-- --------------------------------------------------------

--
-- Table structure for table `event_attendance`
--

CREATE TABLE `event_attendance` (
  `EVENT_NAME` varchar(120) NOT NULL,
  `STUDENT_ID` int(11) NOT NULL,
  `ATTENDANCE_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `event_attendance`
--

INSERT INTO `event_attendance` (`EVENT_NAME`, `STUDENT_ID`, `ATTENDANCE_ID`) VALUES
('Symposium', 555, 3),
('Inter Strand Sports Event', 555, 4),
('Quiz Bee', 11111, 5),
('Inter Strand Sports Event', 12345, 6),
('Film Showing', 555, 7),
('Film Showing', 11111, 8);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `STUDENT_ID` int(11) NOT NULL,
  `FIRST_NAME` varchar(60) NOT NULL,
  `MIDDLE_NAME` varchar(60) NOT NULL,
  `LAST_NAME` varchar(60) NOT NULL,
  `SECTION` varchar(60) NOT NULL,
  `STRAND` varchar(60) NOT NULL,
  `GRADE` varchar(60) NOT NULL,
  `GENDER` varchar(60) NOT NULL,
  `BIRTHDATE` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`STUDENT_ID`, `FIRST_NAME`, `MIDDLE_NAME`, `LAST_NAME`, `SECTION`, `STRAND`, `GRADE`, `GENDER`, `BIRTHDATE`) VALUES
(555, 'Pedro', 'Pedro', 'Santiago', '1', 'ICT', '12', 'Male', '2024-01-01'),
(11111, 'Chriselyn', 'Dela Cruz', 'Asencion', '1', 'ICT', '12', 'Female', '1997-07-29'),
(12345, 'James', 'Resmeros', 'Asencion', '1', 'ICT', '12', 'Male', '2014-05-13');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`EVENT_NAME`);

--
-- Indexes for table `event_attendance`
--
ALTER TABLE `event_attendance`
  ADD PRIMARY KEY (`ATTENDANCE_ID`),
  ADD KEY `EVENT_EVENT_ATTENDANCE` (`EVENT_NAME`),
  ADD KEY `STUDENT_EVENT_ATTENDANCE` (`STUDENT_ID`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`STUDENT_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `event_attendance`
--
ALTER TABLE `event_attendance`
  MODIFY `ATTENDANCE_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `event_attendance`
--
ALTER TABLE `event_attendance`
  ADD CONSTRAINT `EVENT_EVENT_ATTENDANCE` FOREIGN KEY (`EVENT_NAME`) REFERENCES `event` (`EVENT_NAME`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `STUDENT_EVENT_ATTENDANCE` FOREIGN KEY (`STUDENT_ID`) REFERENCES `student` (`STUDENT_ID`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
