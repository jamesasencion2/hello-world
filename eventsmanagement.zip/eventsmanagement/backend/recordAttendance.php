<?php
include "./db/db_connection.php";         
session_start();
// foreach($_POST as $k=>$v) $p[$k] = mysql_real_escape_string($v);
if(isset($_POST['submit'])){
    $studentID = $_POST['studentID'];
    $eventName = $_POST['eventName'];
    if($eventName != "" && $studentID != ""){
        $sql = "INSERT INTO event_attendance(STUDENT_ID,EVENT_NAME) VALUES('{$studentID}','{$eventName}')";
        if (mysqli_query($con, $sql)) {
            header("location: ../success_attendance.php");
        } else {
             alert("Something went wrong. Please try again later.");
        }
    }else{
        alert("Event Name, Details, Organizer, Date, Time and venue cannot be empty!");
    }
safe_query();
ob_clean();
echo 1;
}

?>