<?php
include "./db/db_connection.php";         
session_start();
// foreach($_POST as $k=>$v) $p[$k] = mysql_real_escape_string($v);
if(isset($_POST['submit'])){
    $eventName = $_POST['eventName'];
    $eventDetails = $_POST['eventDetails'];
    $eventOrganizer = $_POST['eventOrganizer'];
    $eventDate = $_POST['eventDate'];
    $eventTime = $_POST['eventTime'];
    $eventVenue = $_POST['eventVenue'];
    if($eventName != "" && $eventDetails != "" && $eventOrganizer != "" && $eventDate != "" && $eventTime != "" && $eventVenue != "" ){
        $sql = "INSERT INTO event(EVENT_NAME,EVENT_DETAILS,EVENT_ORGANIZER,EVENT_DATE,EVENT_TIME,EVENT_VENUE) VALUES('{$eventName}','{$eventDetails}','{$eventOrganizer}','{$eventDate}','{$eventTime}','{$eventVenue}')";
        if (mysqli_query($con, $sql)) {
            header("location: ../success_event.php");
        } else {
             alert("Something went wrong. Please try again later.");
        }
    }else{
        alert("Event Name, Details, Organizer, Date, Time and venue cannot be empty!");
    }
safe_query();
ob_clean();
echo 1;
}

?>