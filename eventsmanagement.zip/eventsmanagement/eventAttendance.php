<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Homepage</title>

    <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>
    <link rel="shortcut icon" href="images/kxp_fav.png" type="image/x-icon">
    <link rel='stylesheet' type='text/css' href='./styling/bootstrap.min.css'>
    <link rel="stylesheet" href="./styling/dstyle.css">

</head>

<body>

    <div class="sidebar close">
        <a href="#" class="logo-box">
            <i class='bx bxl-xing'></i>
            <div class="logo-name">QREvent</div>
        </a>

        <ul class="sidebar-list">
            <li>
                <div class="title">
                    <a href="dashboard.php" class="link">
                        <i class='bx bx-grid-alt'></i>
                        <span class="name">Dashboard</span>
                    </a>
                </div>
                <div class="submenu">
                    <a href="dashboard.php" class="link submenu-title">Dashboard</a>
                </div>
            </li>
            <li class="dropdown">
                <div class="title">
                    <a href="students.php" class="link">
                        <i class='bx bx-book-alt'></i>
                        <span class="name">Entries</span>
                    </a>
                    <i class='bx bxs-chevron-down'></i>
                </div>
                <div class="submenu">
                    <a href="students.php" class="link submenu-title">Students List</a>
                </div>
            </li>

            <li>
                <div class="title">
                    <a href="newevent.php" class="link">
                        <i class='bx bx-line-chart'></i>
                        <span class="name">New Event</span>
                    </a>
                </div>
                <div class="submenu">
                    <a href="newevent.php" class="link submenu-title">Add Event</a>
                </div>
            </li>

            <li>
                <div class="title">
                    <a href="newstudent.php" class="link">
                        <i class='bx bx-line-chart'></i>
                        <span class="name">Add Student</span>
                    </a>
                </div>
                <div class="submenu">
                    <a href="newstudent.php" class="link submenu-title">Add Student</a>
                </div>
            </li>
            <li>
                <div class="title">
                    <a href="eventAttendance.php" class="link">
                        <i class='bx bx-history'></i>
                        <span class="name">Record Event Attendance</span>
                    </a>
                </div>
                <div class="submenu">
                    <a href="eventAttendance.php" class="link submenu-title">Record Event Attendance</a>
                </div>
            </li>
        </ul>
    </div>


    <section class="home">
        <div class="toggle-sidebar">
            <i class='bx bx-menu'></i>
        </div>
        <div style="margin-left: 50px">
       
        <h2>Record Event Attendance</h2>
            <div class="col-md-2">
                <form action="./backend/recordAttendance.php" method="post">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Student ID</label>
                        <input type="text" class="form-control" name="studentID" aria-describedby="emailHelp" placeholder="Student ID">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Event Name</label>
                        <input type="text" class="form-control" name="eventName" placeholder="Event Name">
                    </div>
                    <input type="submit" name="submit" id="submit" class="btn btn-success pull-right" style="margin-top: 20px">
                </form>
            </div>
        </div>
    </section>
    <div class="main--content">

    </div>


    <script src="dmain.js"></script>

    <a href="logout.php">Logout</a>
</body>
</html>