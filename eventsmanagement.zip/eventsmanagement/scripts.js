const signInButton=document.getElementById('signInButton');
const signInForm=document.getElementById('signIn');

signInButton.addEventListener('click', function(){
    signInForm.style.display="block";
    signUpForm.style.display="none";
})