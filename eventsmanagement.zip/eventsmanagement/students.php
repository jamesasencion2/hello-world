<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Homepage</title>

    <link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>
    <link rel="shortcut icon" href="images/kxp_fav.png" type="image/x-icon">
    <link rel='stylesheet' type='text/css' href='./styling/bootstrap.min.css'>
    <link rel="stylesheet" href="./styling/dstyle.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    
</head>

<body>
<script src="./styling/bootstrap.bundle.min.js"></script>

    <div class="sidebar close">
        <a href="#" class="logo-box">
            <i class='bx bxl-xing'></i>
            <div class="logo-name">QREvent</div>
        </a>

        <ul class="sidebar-list">
            <li>
                <div class="title">
                    <a href="dashboard.php" class="link">
                        <i class='bx bx-grid-alt'></i>
                        <span class="name">Dashboard</span>
                    </a>
                </div>
                <div class="submenu">
                    <a href="dashboard.php" class="link submenu-title">Dashboard</a>
                </div>
            </li>
            <li class="dropdown">
                <div class="title">
                    <a href="students.php" class="link">
                        <i class='bx bx-book-alt'></i>
                        <span class="name">Entries</span>
                    </a>
                    <i class='bx bxs-chevron-down'></i>
                </div>
                <div class="submenu">
                    <a href="students.php" class="link submenu-title">Students List</a>
                </div>
            </li>

            <li>
                <div class="title">
                    <a href="newevent.php" class="link">
                        <i class='bx bx-line-chart'></i>
                        <span class="name">New Event</span>
                    </a>
                </div>
                <div class="submenu">
                    <a href="newevent.php" class="link submenu-title">Add Event</a>
                </div>
            </li>

            <li>
                <div class="title">
                    <a href="newstudent.php" class="link">
                        <i class='bx bx-line-chart'></i>
                        <span class="name">Add Student</span>
                    </a>
                </div>
                <div class="submenu">
                    <a href="newstudent.php" class="link submenu-title">Add Student</a>
                </div>
            </li>
            <li>
                <div class="title">
                    <a href="eventAttendance.php" class="link">
                        <i class='bx bx-history'></i>
                        <span class="name">Record Event Attendance</span>
                    </a>
                </div>
                <div class="submenu">
                    <a href="eventAttendance.php" class="link submenu-title">Record Event Attendance</a>
                </div>
            </li>
        </ul>
    </div>


    <section class="home">
        <div class="toggle-sidebar">
            <i class='bx bx-menu'></i>
        </div>
        <div class="d-flex justify-content-left">
                    
            <div class="d-flex flex-column mb-8">                    
                <div class="col-md-8" style="margin: 15px">     
                </div> 
                <div style="margin: 15px"> <h4>Students List</h4> </div>
                <div class="col-md-12" style="margin: 15px"> 
                
                    <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Student ID</th>
                                    <th scope="col">First Name</th>
                                    <th scope="col">Middle Name</th>
                                    <th scope="col">Last Name</th>
                                    <th scope="col">Birthdate</th>
                                    <th scope="col">Gender</th>
                                    <th scope="col">Grade</th>
                                    <th scope="col">Strand</th>
                                    <th scope="col">Section</th>
                                </tr>
                            </thead>
                            <?php 
                        require_once "./backend/db/db_connection.php";
                        $sql_query = "SELECT * FROM student";
                        if ($result = $con ->query($sql_query)) {
                            while ($row = $result -> fetch_assoc()) { 
                                $STUDENT_ID = $row['STUDENT_ID']; 
                                $FIRST_NAME = $row['FIRST_NAME']; 
                                $MIDDLE_NAME = $row['MIDDLE_NAME']; 
                                $LAST_NAME = $row['LAST_NAME'];
                                $BIRTHDATE = $row['BIRTHDATE'];
                                $GENDER = $row['GENDER'];
                                $STRAND = $row['STRAND'];
                                $SECTION = $row['SECTION'];
                                $GRADE = $row['GRADE'];
                    ?>    
                            <tbody>
                                <tr>
                                    <td><?php echo $STUDENT_ID; ?></td>
                                    <td><?php echo $FIRST_NAME; ?></td>
                                    <td><?php echo $MIDDLE_NAME; ?></td>
                                    <td><?php echo $LAST_NAME; ?></td>
                                    <td><?php echo $BIRTHDATE; ?></td>
                                    <td><?php echo $GENDER; ?></td>
                                    <td><?php echo $GRADE; ?></td>
                                    <td><?php echo $STRAND; ?></td>
                                    <td><?php echo $SECTION; ?></td>
                                </tr>
                            </tbody>
                            
                    <?php
                                    } 
                                } 
                    ?>
                    </table>
                                
                
                </div>  
            </div> 
        </div>
    </section>
    <div class="main--content">
    </div>
    </div>
    

    <script src="dmain.js"></script>

    <a href="logout.php">Logout</a>
</body>

</html>